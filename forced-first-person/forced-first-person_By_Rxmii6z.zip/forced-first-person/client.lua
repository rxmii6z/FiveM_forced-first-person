Citizen.CreateThread(function()
    while true do
        Wait(0)
        DisableControlAction(0, 0, true)
        SetFollowPedCamViewMode(4)
    end
end)
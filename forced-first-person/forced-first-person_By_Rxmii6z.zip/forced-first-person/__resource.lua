author 'Rxmii6z'
description 'Discord : https://discord.gg/rRvzeRjUXX'


client_script 'client.lua'